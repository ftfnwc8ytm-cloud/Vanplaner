import { useState, useMemo } from 'react'
import { catalog, sources, categoryColors, Product } from '../data/catalog'
import { useSceneStore } from '../stores/sceneStore'
import { Search, Star } from 'lucide-react'
import toast from 'react-hot-toast'

export function LeftPanel() {
  const [tab, setTab] = useState<'all' | 'ikea' | 'decathlon' | 'van' | 'electrical'>('all')
  const [query, setQuery] = useState('')
  const addObject = useSceneStore((s) => s.addObject)
  const van = useSceneStore((s) => s.currentVan())

  const filtered = useMemo(() => {
    let items = catalog
    if (tab !== 'all') items = items.filter((p) => p.source === tab)
    if (query.trim()) {
      const q = query.toLowerCase()
      items = items.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.tags.some((t) => t.toLowerCase().includes(q))
      )
    }
    return items
  }, [tab, query])

  const handleAdd = (p: Product) => {
    // Placer au centre du van au sol
    const cx = van.interior.length / 2 - p.dimensions.length / 2
    const layerId = mapCategoryToLayer(p.category)
    addObject({
      productId: p.id,
      position: [cx, 0, 0],
      rotation: [0, 0, 0],
      layerId
    })
    toast.success(`${p.name} ajouté`)
  }

  return (
    <div className="w-80 h-full bg-bg-800 border-r border-bg-600 flex flex-col">
      <div className="p-2 border-b border-bg-600">
        <div className="flex gap-1 mb-2">
          {(['all', 'ikea', 'decathlon', 'van', 'electrical'] as const).map((t) => (
            <button
              key={t}
              className={`px-2 py-1 text-xs rounded ${tab === t ? 'bg-accent-blue text-white' : 'bg-bg-700 text-gray-400 hover:bg-bg-600'}`}
              onClick={() => setTab(t)}
            >
              {t === 'all' ? 'Tous' : sources[t as keyof typeof sources].name}
            </button>
          ))}
        </div>
        <div className="relative">
          <Search size={14} className="absolute left-2 top-2.5 text-gray-500" />
          <input
            className="input w-full pl-7"
            placeholder="Rechercher un produit..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <div className="text-xs text-gray-500 mt-2">{filtered.length} produits</div>
      </div>

      <div className="flex-1 overflow-y-auto p-2 space-y-1.5">
        {filtered.map((p) => (
          <div
            key={p.id}
            className="panel p-2 rounded cursor-pointer hover:border-accent-blue transition-colors"
            onClick={() => handleAdd(p)}
          >
            <div className="flex items-start gap-2">
              <div
                className="w-10 h-10 rounded flex-shrink-0"
                style={{ background: categoryColors[p.category] || p.color }}
              />
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium truncate">{p.name}</div>
                <div className="text-xs text-gray-500 truncate">
                  {p.dimensions.length}×{p.dimensions.width}×{p.dimensions.height} mm · {(p.weight / 1000).toFixed(1)} kg
                </div>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-xs font-mono text-accent-blue">{p.price.toFixed(2)}€</span>
                  <span className="flex items-center gap-0.5">
                    {Array.from({ length: p.vanRating }).map((_, i) => (
                      <Star key={i} size={9} className="text-accent-orange" fill="currentColor" />
                    ))}
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function mapCategoryToLayer(category: string): string {
  const map: Record<string, string> = {
    Rangement: 'rangement',
    Cuisine: 'cuisine',
    Couchage: 'couchage',
    Textile: 'textile',
    Éclairage: 'eclairage',
    Table: 'mobilier',
    Siège: 'mobilier',
    Eau: 'eau',
    Sanitaire: 'sanitaire',
    Ouvrant: 'structure',
    Chauffage: 'chauffage',
    Électricité: 'electrique'
  }
  return map[category] || 'mobilier'
}
