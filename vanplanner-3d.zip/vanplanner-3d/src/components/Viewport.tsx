import { Canvas } from '@react-three/fiber'
import { OrbitControls, Grid, Sky } from '@react-three/drei'
import { useSceneStore } from '../stores/sceneStore'
import { VanModel } from '../three/VanModel'
import { ProductMesh } from '../three/ProductMesh'

export function Viewport() {
  const van = useSceneStore((s) => s.currentVan())
  const popTop = useSceneStore((s) => s.popTopRaised)
  const objects = useSceneStore((s) => s.objects)
  const selectedIds = useSceneStore((s) => s.selectedIds)
  const layers = useSceneStore((s) => s.layers)
  const showGrid = useSceneStore((s) => s.showGrid)
  const renderMode = useSceneStore((s) => s.renderMode)
  const selectObject = useSceneStore((s) => s.selectObject)

  const visibleObjects = objects.filter((o) => {
    const l = layers.find((x) => x.id === o.layerId)
    return l?.visible !== false
  })

  return (
    <Canvas
      shadows={renderMode !== 'wireframe'}
      camera={{ position: [6, 4, 6], fov: 45 }}
      onPointerMissed={() => selectObject(null)}
    >
      <ambientLight intensity={0.6} />
      <directionalLight
        position={[8, 10, 6]}
        intensity={1.1}
        castShadow
        shadow-mapSize={[1024, 1024]}
      />
      <hemisphereLight color="#87ceeb" groundColor="#2a2a2a" intensity={0.4} />

      {renderMode === 'sketchup' && <Sky sunPosition={[100, 20, 100]} />}

      {showGrid && (
        <Grid
          args={[20, 20]}
          cellSize={0.5}
          cellThickness={0.5}
          cellColor="#3a3a3a"
          sectionSize={2}
          sectionThickness={1}
          sectionColor="#4a5568"
          fadeDistance={20}
          fadeStrength={1}
          followCamera={false}
          infiniteGrid
        />
      )}

      <VanModel van={van} popTopRaised={popTop} wireframe={renderMode === 'wireframe'} />

      {visibleObjects.map((o) => (
        <ProductMesh key={o.id} object={o} selected={selectedIds.includes(o.id)} />
      ))}

      <OrbitControls makeDefault target={[van.interior.length / 2000, 0.8, 0]} />
    </Canvas>
  )
}
