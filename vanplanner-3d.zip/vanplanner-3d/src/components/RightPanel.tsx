import { useState } from 'react'
import { useSceneStore } from '../stores/sceneStore'
import { catalog } from '../data/catalog'
import { Eye, EyeOff, Lock, Trash2 } from 'lucide-react'

type Tab = 'properties' | 'layers' | 'totals' | 'vasp'

export function RightPanel() {
  const [tab, setTab] = useState<Tab>('totals')
  const objects = useSceneStore((s) => s.objects)
  const selectedIds = useSceneStore((s) => s.selectedIds)
  const layers = useSceneStore((s) => s.layers)
  const toggleLayer = useSceneStore((s) => s.toggleLayer)
  const updateObject = useSceneStore((s) => s.updateObject)
  const removeObject = useSceneStore((s) => s.removeObject)
  const van = useSceneStore((s) => s.currentVan())

  const selected = objects.find((o) => o.id === selectedIds[0])
  const selectedProduct = selected ? catalog.find((p) => p.id === selected.productId) : null

  // === Calculs totaux ===
  const totals = objects.reduce(
    (acc, o) => {
      const p = catalog.find((x) => x.id === o.productId)
      if (!p) return acc
      acc.price += p.price
      acc.weight += p.weight / 1000 // grammes → kg
      const cat = p.category
      acc.byCategory[cat] = acc.byCategory[cat] || { count: 0, price: 0, weight: 0 }
      acc.byCategory[cat].count += 1
      acc.byCategory[cat].price += p.price
      acc.byCategory[cat].weight += p.weight / 1000
      return acc
    },
    { price: 0, weight: 0, byCategory: {} as Record<string, { count: number; price: number; weight: number }> }
  )

  const payloadPct = (totals.weight / van.payload) * 100
  const payloadOK = payloadPct < 90

  // === VASP checklist ===
  const vaspChecks = [
    { id: 'cuisine', label: 'Cuisine fixe (évier + réchaud)', done: totals.byCategory['Cuisine']?.count >= 1 },
    { id: 'couchage', label: 'Couchage fixe (matelas)', done: totals.byCategory['Couchage']?.count >= 1 },
    { id: 'table', label: 'Table fixe', done: totals.byCategory['Table']?.count >= 1 },
    { id: 'siege', label: 'Au moins 2 sièges', done: (totals.byCategory['Siège']?.count ?? 0) >= 2 },
    { id: 'rangement', label: 'Rangement fixe', done: totals.byCategory['Rangement']?.count >= 1 },
    { id: 'hauteur', label: 'Hauteur intérieure ≥ 1800 mm', done: van.interior.height >= 1800 },
    { id: 'poids', label: 'Charge utile respectée', done: payloadOK }
  ]
  const vaspScore = Math.round((vaspChecks.filter((c) => c.done).length / vaspChecks.length) * 100)

  return (
    <div className="w-80 h-full bg-bg-800 border-l border-bg-600 flex flex-col">
      {/* Onglets */}
      <div className="flex border-b border-bg-600">
        {(['properties', 'layers', 'totals', 'vasp'] as Tab[]).map((t) => (
          <button
            key={t}
            className={`flex-1 py-2 text-xs uppercase font-medium ${
              tab === t ? 'text-accent-blue border-b-2 border-accent-blue' : 'text-gray-500 hover:text-gray-300'
            }`}
            onClick={() => setTab(t)}
          >
            {t === 'properties' && 'Objet'}
            {t === 'layers' && 'Calques'}
            {t === 'totals' && 'Totaux'}
            {t === 'vasp' && 'VASP'}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto p-3">
        {/* === PROPRIÉTÉS === */}
        {tab === 'properties' && (
          <>
            {!selected && (
              <div className="text-sm text-gray-500 text-center py-8">
                Sélectionnez un objet dans la scène 3D
              </div>
            )}
            {selected && selectedProduct && (
              <div className="space-y-3">
                <div>
                  <div className="text-sm font-medium">{selectedProduct.name}</div>
                  <div className="text-xs text-gray-500">{selectedProduct.reference}</div>
                </div>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div><div className="text-gray-500">L</div><div className="font-mono">{selectedProduct.dimensions.length} mm</div></div>
                  <div><div className="text-gray-500">l</div><div className="font-mono">{selectedProduct.dimensions.width} mm</div></div>
                  <div><div className="text-gray-500">H</div><div className="font-mono">{selectedProduct.dimensions.height} mm</div></div>
                </div>
                <div className="text-xs">
                  <div className="text-gray-500">Poids</div>
                  <div className="font-mono">{(selectedProduct.weight / 1000).toFixed(2)} kg</div>
                </div>
                <div className="text-xs">
                  <div className="text-gray-500">Prix</div>
                  <div className="font-mono text-accent-blue">{selectedProduct.price.toFixed(2)} €</div>
                </div>

                <div className="pt-2 border-t border-bg-600">
                  <label className="text-xs text-gray-500">Position (mm)</label>
                  <div className="grid grid-cols-3 gap-1 mt-1">
                    {(['X', 'Y', 'Z'] as const).map((axis, i) => (
                      <input
                        key={axis}
                        type="number"
                        className="input font-mono"
                        value={Math.round(selected.position[i])}
                        onChange={(e) => {
                          const v = parseFloat(e.target.value) || 0
                          const pos: [number, number, number] = [...selected.position]
                          pos[i] = v
                          updateObject(selected.id, { position: pos })
                        }}
                      />
                    ))}
                  </div>
                </div>

                <button
                  className="btn w-full bg-red-600 hover:bg-red-700 text-white flex items-center justify-center gap-2 mt-4"
                  onClick={() => removeObject(selected.id)}
                >
                  <Trash2 size={14} /> Supprimer
                </button>
              </div>
            )}
          </>
        )}

        {/* === CALQUES === */}
        {tab === 'layers' && (
          <div className="space-y-1">
            {layers.map((l) => (
              <div
                key={l.id}
                className="flex items-center gap-2 p-1.5 rounded hover:bg-bg-700"
              >
                <button onClick={() => toggleLayer(l.id)}>
                  {l.visible ? <Eye size={14} /> : <EyeOff size={14} className="text-gray-500" />}
                </button>
                <div className="w-3 h-3 rounded" style={{ background: l.color }} />
                <span className={`text-sm flex-1 ${!l.visible ? 'text-gray-500' : ''}`}>{l.name}</span>
                <span className="text-xs text-gray-500">
                  {objects.filter((o) => o.layerId === l.id).length}
                </span>
              </div>
            ))}
          </div>
        )}

        {/* === TOTAUX === */}
        {tab === 'totals' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-2">
              <div className="panel p-3 rounded">
                <div className="text-xs text-gray-500">Prix total</div>
                <div className="text-lg font-mono text-accent-blue">{totals.price.toFixed(2)} €</div>
              </div>
              <div className="panel p-3 rounded">
                <div className="text-xs text-gray-500">Poids total</div>
                <div className={`text-lg font-mono ${payloadOK ? 'text-white' : 'text-red-500'}`}>
                  {totals.weight.toFixed(1)} kg
                </div>
              </div>
            </div>

            {/* Barre charge utile */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-gray-500">Charge utile</span>
                <span className={payloadOK ? 'text-gray-400' : 'text-red-500'}>
                  {totals.weight.toFixed(0)} / {van.payload} kg ({payloadPct.toFixed(0)}%)
                </span>
              </div>
              <div className="h-2 bg-bg-700 rounded overflow-hidden">
                <div
                  className={`h-full ${payloadOK ? 'bg-accent-blue' : 'bg-red-600'}`}
                  style={{ width: `${Math.min(payloadPct, 100)}%` }}
                />
              </div>
              {!payloadOK && (
                <div className="text-xs text-red-500 mt-1">
                  ⚠️ Dépassement charge utile — homologation compromise
                </div>
              )}
            </div>

            <div>
              <div className="text-xs uppercase text-gray-500 mb-2">Par catégorie</div>
              <div className="space-y-1">
                {Object.entries(totals.byCategory)
                  .sort((a, b) => b[1].price - a[1].price)
                  .map(([cat, v]) => (
                    <div key={cat} className="flex items-center justify-between text-xs py-1 border-b border-bg-700">
                      <span>{cat} <span className="text-gray-500">({v.count})</span></span>
                      <span className="font-mono">
                        {v.weight.toFixed(1)}kg <span className="text-accent-blue">{v.price.toFixed(0)}€</span>
                      </span>
                    </div>
                  ))}
              </div>
            </div>

            <div className="text-xs text-gray-500 pt-2 border-t border-bg-700">
              {objects.length} objet(s) dans la scène
            </div>
          </div>
        )}

        {/* === VASP === */}
        {tab === 'vasp' && (
          <div className="space-y-3">
            <div className="panel p-3 rounded">
              <div className="text-xs text-gray-500">Score homologation VASP</div>
              <div className={`text-2xl font-mono ${vaspScore >= 80 ? 'text-green-500' : vaspScore >= 50 ? 'text-accent-orange' : 'text-red-500'}`}>
                {vaspScore}%
              </div>
            </div>

            <div className="space-y-1">
              {vaspChecks.map((c) => (
                <div key={c.id} className="flex items-center gap-2 text-sm">
                  <span className={c.done ? 'text-green-500' : 'text-gray-500'}>
                    {c.done ? '✓' : '○'}
                  </span>
                  <span className={c.done ? '' : 'text-gray-500'}>{c.label}</span>
                </div>
              ))}
            </div>

            <div className="text-xs text-gray-500 pt-2 border-t border-bg-700">
              ⚠️ Aide à la préparation — validation finale DREAL + centre agréé (arrêté du 5 novembre 1984).
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
