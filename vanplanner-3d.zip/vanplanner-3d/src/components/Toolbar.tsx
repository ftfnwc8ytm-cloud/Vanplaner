import { useSceneStore } from '../stores/sceneStore'
import { vans, vanCategories } from '../data/vans'
import { presets } from '../data/presets'
import {
  Grid3x3,
  Layers as LayersIcon,
  Sun,
  Box,
  Palette,
  Save,
  FolderOpen,
  Plus,
  ChevronDown
} from 'lucide-react'
import { useState } from 'react'
import toast from 'react-hot-toast'
import { exportProject, importProject } from '../utils/serialize'

export function Toolbar() {
  const vanId = useSceneStore((s) => s.vanId)
  const setVan = useSceneStore((s) => s.setVan)
  const popTop = useSceneStore((s) => s.popTopRaised)
  const setPopTop = useSceneStore((s) => s.setPopTop)
  const renderMode = useSceneStore((s) => s.renderMode)
  const setRenderMode = useSceneStore((s) => s.setRenderMode)
  const toggleGrid = useSceneStore((s) => s.toggleGrid)
  const toggleMultiView = useSceneStore((s) => s.toggleMultiView)
  const loadPreset = useSceneStore((s) => s.loadPreset)
  const clearScene = useSceneStore((s) => s.clearScene)
  const currentVan = useSceneStore((s) => s.currentVan())

  const [showVans, setShowVans] = useState(false)
  const [showPresets, setShowPresets] = useState(false)
  const [showRender, setShowRender] = useState(false)

  const groupedVans = Object.entries(vanCategories).map(([cat, label]) => ({
    cat, label, vans: vans.filter((v) => v.category === cat)
  }))

  const handleImport = () => {
    const input = document.createElement('input')
    input.type = 'file'
    input.accept = '.json,.vanplan.json'
    input.onchange = async (e: any) => {
      const file = e.target.files?.[0]
      if (!file) return
      try {
        const text = await file.text()
        importProject(text)
        toast.success('Projet chargé avec succès')
      } catch (err) {
        toast.error('Erreur lors du chargement')
      }
    }
    input.click()
  }

  const handleExport = () => {
    exportProject()
    toast.success('Projet exporté')
  }

  return (
    <div className="h-12 bg-bg-800 border-b border-bg-600 flex items-center px-3 gap-2 text-sm">
      {/* Logo */}
      <div className="flex items-center gap-2 mr-4">
        <div className="w-8 h-8 rounded bg-accent-blue flex items-center justify-center text-white font-bold">V</div>
        <span className="font-semibold text-white">VanPlanner 3D</span>
      </div>

      {/* Nouveau projet */}
      <button
        className="btn-ghost flex items-center gap-1"
        onClick={() => {
          if (confirm('Créer un nouveau projet vierge ?')) clearScene()
        }}
      >
        <Plus size={14} /> Nouveau
      </button>

      <button className="btn-ghost flex items-center gap-1" onClick={handleImport}>
        <FolderOpen size={14} /> Ouvrir
      </button>

      <button className="btn-ghost flex items-center gap-1" onClick={handleExport}>
        <Save size={14} /> Enregistrer
      </button>

      <div className="w-px h-6 bg-bg-600 mx-1" />

      {/* Sélecteur van */}
      <div className="relative">
        <button
          className="btn-ghost flex items-center gap-2"
          onClick={() => { setShowVans((v) => !v); setShowPresets(false); setShowRender(false) }}
        >
          <Box size={14} />
          <span>{currentVan.brand} {currentVan.model} <span className="text-gray-500">— {currentVan.variant}</span></span>
          <ChevronDown size={12} />
        </button>
        {showVans && (
          <div className="absolute top-11 left-0 w-96 max-h-[70vh] overflow-y-auto panel rounded shadow-lg z-50 p-2">
            {groupedVans.map((g) => (
              <div key={g.cat} className="mb-2">
                <div className="text-xs uppercase text-gray-500 px-2 py-1">{g.label}</div>
                {g.vans.map((v) => (
                  <button
                    key={v.id}
                    className={`w-full text-left px-2 py-1.5 rounded hover:bg-bg-700 ${vanId === v.id ? 'bg-bg-700' : ''}`}
                    onClick={() => { setVan(v.id); setShowVans(false) }}
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded" style={{ background: v.color }} />
                      <span className="font-medium">{v.brand} {v.model}</span>
                      <span className="text-xs text-gray-500">{v.variant}</span>
                      {v.popTop && <span className="ml-auto text-xs text-accent-orange">Toit relevable</span>}
                    </div>
                    <div className="text-xs text-gray-500 pl-5">
                      {v.interior.length}×{v.interior.width}×{v.interior.height} mm — {v.payload} kg utile
                    </div>
                  </button>
                ))}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Toit relevable toggle */}
      {currentVan.popTop && (
        <button
          className={`btn-ghost ${popTop ? 'text-accent-orange' : ''}`}
          onClick={() => setPopTop(!popTop)}
        >
          Toit {popTop ? 'relevé' : 'baissé'}
        </button>
      )}

      <div className="w-px h-6 bg-bg-600 mx-1" />

      {/* Presets */}
      <div className="relative">
        <button
          className="btn-ghost flex items-center gap-1"
          onClick={() => { setShowPresets((v) => !v); setShowVans(false); setShowRender(false) }}
        >
          <Palette size={14} /> Presets <ChevronDown size={12} />
        </button>
        {showPresets && (
          <div className="absolute top-11 left-0 w-80 panel rounded shadow-lg z-50 p-2">
            {presets.map((p) => (
              <button
                key={p.id}
                className="w-full text-left px-2 py-2 rounded hover:bg-bg-700 flex items-start gap-2"
                onClick={() => {
                  loadPreset(p.id)
                  setShowPresets(false)
                  toast.success(`Preset "${p.name}" chargé`)
                }}
              >
                <span className="text-2xl">{p.icon}</span>
                <div className="flex-1">
                  <div className="font-medium">{p.name}</div>
                  <div className="text-xs text-gray-500 line-clamp-2">{p.description}</div>
                  <div className="text-xs text-accent-blue mt-1">
                    ~{p.estimatedBudget}€ · {p.estimatedWeight} kg
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Mode rendu */}
      <div className="relative">
        <button
          className="btn-ghost flex items-center gap-1"
          onClick={() => { setShowRender((v) => !v); setShowVans(false); setShowPresets(false) }}
        >
          <Sun size={14} /> Rendu : {renderMode} <ChevronDown size={12} />
        </button>
        {showRender && (
          <div className="absolute top-11 left-0 w-48 panel rounded shadow-lg z-50 p-1">
            {(['wireframe', 'solid', 'shaded', 'sketchup'] as const).map((m) => (
              <button
                key={m}
                className={`w-full text-left px-3 py-1.5 rounded hover:bg-bg-700 ${renderMode === m ? 'bg-bg-700 text-accent-blue' : ''}`}
                onClick={() => { setRenderMode(m); setShowRender(false) }}
              >
                {m === 'wireframe' && 'Filaire'}
                {m === 'solid' && 'Solide'}
                {m === 'shaded' && 'Ombré'}
                {m === 'sketchup' && 'SketchUp + Skydome'}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="w-px h-6 bg-bg-600 mx-1" />

      <button className="btn-ghost" onClick={toggleGrid}>
        <Grid3x3 size={14} />
      </button>

      <button className="btn-ghost" onClick={toggleMultiView}>
        <LayersIcon size={14} />
      </button>

      <div className="ml-auto text-xs text-gray-500">
        v1.0 · PWA · Offline-ready
      </div>
    </div>
  )
}
