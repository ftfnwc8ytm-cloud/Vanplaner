import { z } from 'zod'
import { saveAs } from 'file-saver'
import { useSceneStore } from '../stores/sceneStore'

const projectSchema = z.object({
  version: z.literal('1.0'),
  metadata: z.object({
    name: z.string(),
    createdAt: z.string(),
    updatedAt: z.string()
  }),
  vanId: z.string(),
  popTopRaised: z.boolean().optional(),
  objects: z.array(
    z.object({
      id: z.string(),
      productId: z.string(),
      position: z.tuple([z.number(), z.number(), z.number()]),
      rotation: z.tuple([z.number(), z.number(), z.number()]),
      layerId: z.string(),
      locked: z.boolean().optional()
    })
  ),
  layers: z.array(
    z.object({
      id: z.string(),
      name: z.string(),
      visible: z.boolean(),
      locked: z.boolean(),
      color: z.string()
    })
  )
})

export type Project = z.infer<typeof projectSchema>

export function exportProject(name = 'mon-van') {
  const store = useSceneStore.getState()
  const project: Project = {
    version: '1.0',
    metadata: {
      name,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    vanId: store.vanId,
    popTopRaised: store.popTopRaised,
    objects: store.objects,
    layers: store.layers
  }
  const blob = new Blob([JSON.stringify(project, null, 2)], {
    type: 'application/json'
  })
  saveAs(blob, `${name}.vanplan.json`)
}

export function importProject(text: string) {
  const raw = JSON.parse(text)
  const parsed = projectSchema.parse(raw)
  const store = useSceneStore.getState()
  store.setVan(parsed.vanId)
  store.setPopTop(parsed.popTopRaised ?? false)
  // Remplacer les objets
  useSceneStore.setState({
    objects: parsed.objects,
    layers: parsed.layers,
    selectedIds: []
  })
}
