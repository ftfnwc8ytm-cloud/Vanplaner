// Presets d'aménagement type — profils van-life courants

export interface PresetObject {
  productId: string
  position: [number, number, number] // mm, dans le repère van (x=long, y=hauteur, z=lat)
  rotation: [number, number, number]
  layerId: string
}

export interface Preset {
  id: string
  name: string
  icon: string
  description: string
  defaultVanId: string
  objects: PresetObject[]
  estimatedBudget: number
  estimatedWeight: number
  tags: string[]
}

export const presets: Preset[] = [
  {
    id: 'couple-weekend',
    name: 'Couple Weekend',
    icon: '💑',
    description: 'Aménagement optimisé pour escapades 2-3 jours en couple. Lit fixe, kitchenette compacte, rangements malins.',
    defaultVanId: 'ford-custom-l2',
    objects: [
      { productId: 'ikea-malfors-140', position: [1900, 200, 0], rotation: [0, 0, 0], layerId: 'couchage' },
      { productId: 'ikea-raskog', position: [500, 0, 500], rotation: [0, 0, 0], layerId: 'cuisine' },
      { productId: 'dcth-mh100-rechaud', position: [500, 820, 500], rotation: [0, 0, 0], layerId: 'cuisine' },
      { productId: 'dcth-glaciere-25', position: [500, 0, -500], rotation: [0, 0, 0], layerId: 'cuisine' },
      { productId: 'ikea-samla-45', position: [1200, 0, -600], rotation: [0, 0, 0], layerId: 'rangement' },
      { productId: 'ikea-samla-45', position: [1200, 300, -600], rotation: [0, 0, 0], layerId: 'rangement' },
      { productId: 'dcth-bl500', position: [1000, 1200, -700], rotation: [0, 0, 0], layerId: 'eclairage' },
      { productId: 'dcth-bl500', position: [1000, 1200, 700], rotation: [0, 0, 0], layerId: 'eclairage' }
    ],
    estimatedBudget: 830,
    estimatedWeight: 55,
    tags: ['week-end', 'couple', 'minimaliste']
  },
  {
    id: 'nomade-full-time',
    name: 'Nomade Full-Time',
    icon: '🌍',
    description: 'Aménagement complet pour vivre à l\'année. Lit fixe, cuisine complète, sanitaire, chauffage, solaire.',
    defaultVanId: 'fiat-ducato-l3h2',
    objects: [
      { productId: 'ikea-malfors-140', position: [3000, 400, 0], rotation: [0, Math.PI / 2, 0], layerId: 'couchage' },
      { productId: 'ikea-sunnersta', position: [1500, 0, -600], rotation: [0, 0, 0], layerId: 'cuisine' },
      { productId: 'elec-frigo-crx65', position: [2000, 0, -700], rotation: [0, 0, 0], layerId: 'electrique' },
      { productId: 'van-thetford-c223', position: [500, 0, 700], rotation: [0, 0, 0], layerId: 'sanitaire' },
      { productId: 'van-truma-combi-4e', position: [800, 0, -800], rotation: [0, 0, 0], layerId: 'chauffage' },
      { productId: 'ikea-kallax-4x1', position: [2500, 0, 800], rotation: [0, 0, 0], layerId: 'rangement' },
      { productId: 'ikea-norberg', position: [1200, 400, 700], rotation: [0, 0, 0], layerId: 'mobilier' },
      { productId: 'ikea-terje', position: [1200, 0, 300], rotation: [0, 0, 0], layerId: 'mobilier' },
      { productId: 'elec-batt-lifepo4-200', position: [200, 0, 0], rotation: [0, 0, 0], layerId: 'electrique' },
      { productId: 'elec-solar-200w', position: [1500, 1900, 0], rotation: [0, 0, 0], layerId: 'electrique' },
      { productId: 'elec-mppt-victron-100-20', position: [300, 500, 700], rotation: [0, 0, 0], layerId: 'electrique' },
      { productId: 'elec-onduleur-1000', position: [300, 500, -700], rotation: [0, 0, 0], layerId: 'electrique' },
      { productId: 'elec-maxxair', position: [1800, 1900, 0], rotation: [0, 0, 0], layerId: 'electrique' },
      { productId: 'ikea-ledberg', position: [1500, 1850, 0], rotation: [0, 0, 0], layerId: 'eclairage' },
      { productId: 'ikea-marjun', position: [1500, 1000, 900], rotation: [0, 0, 0], layerId: 'textile' }
    ],
    estimatedBudget: 3550,
    estimatedWeight: 210,
    tags: ['full-time', 'autonome', 'complet']
  },
  {
    id: 'famille-4p',
    name: 'Famille 4 personnes',
    icon: '👨‍👩‍👧‍👦',
    description: 'Grand fourgon pour famille. Lit parental + banquette convertible, table pour 4, rangements enfants.',
    defaultVanId: 'fiat-ducato-l4h3',
    objects: [
      { productId: 'ikea-malfors-140', position: [3500, 800, 0], rotation: [0, Math.PI / 2, 0], layerId: 'couchage' },
      { productId: 'ikea-malfors-90', position: [1500, 400, -600], rotation: [0, 0, 0], layerId: 'couchage' },
      { productId: 'ikea-sunnersta', position: [800, 0, 700], rotation: [0, 0, 0], layerId: 'cuisine' },
      { productId: 'ikea-norberg', position: [2200, 500, 0], rotation: [0, 0, 0], layerId: 'mobilier' },
      { productId: 'ikea-terje', position: [2200, 0, 500], rotation: [0, 0, 0], layerId: 'mobilier' },
      { productId: 'ikea-terje', position: [2200, 0, -500], rotation: [0, 0, 0], layerId: 'mobilier' },
      { productId: 'ikea-frosta', position: [2500, 0, 500], rotation: [0, 0, 0], layerId: 'mobilier' },
      { productId: 'ikea-frosta', position: [2500, 0, -500], rotation: [0, 0, 0], layerId: 'mobilier' },
      { productId: 'elec-frigo-crx65', position: [500, 0, -700], rotation: [0, 0, 0], layerId: 'electrique' },
      { productId: 'ikea-kallax-2x2', position: [3500, 0, -700], rotation: [0, 0, 0], layerId: 'rangement' }
    ],
    estimatedBudget: 2650,
    estimatedWeight: 245,
    tags: ['famille', '4 personnes', 'grand fourgon']
  },
  {
    id: 'surf-trip',
    name: 'Surf-Trip',
    icon: '🏄',
    description: 'Van compact pour trips surf. Banquette-lit, rangement planches vertical, douche extérieure.',
    defaultVanId: 'vw-t6-california',
    objects: [
      { productId: 'ikea-malfors-140', position: [1800, 400, 0], rotation: [0, Math.PI / 2, 0], layerId: 'couchage' },
      { productId: 'ikea-raskog', position: [600, 0, -600], rotation: [0, 0, 0], layerId: 'cuisine' },
      { productId: 'dcth-mh500-popote', position: [600, 820, -600], rotation: [0, 0, 0], layerId: 'cuisine' },
      { productId: 'dcth-glaciere-compressor-35', position: [1000, 0, -650], rotation: [0, 0, 0], layerId: 'electrique' },
      { productId: 'dcth-douche-solaire', position: [200, 1500, 700], rotation: [0, 0, 0], layerId: 'sanitaire' },
      { productId: 'dcth-solaire-20w', position: [1500, 1400, 0], rotation: [0, 0, 0], layerId: 'electrique' },
      { productId: 'dcth-table-mh500', position: [2400, 0, 0], rotation: [0, 0, 0], layerId: 'mobilier' },
      { productId: 'dcth-chaise-comfort', position: [2400, 0, 600], rotation: [0, 0, 0], layerId: 'mobilier' },
      { productId: 'dcth-chaise-comfort', position: [2400, 0, -600], rotation: [0, 0, 0], layerId: 'mobilier' }
    ],
    estimatedBudget: 1250,
    estimatedWeight: 85,
    tags: ['surf', 'sport', 'compact']
  },
  {
    id: 'digital-nomad',
    name: 'Digital Nomad',
    icon: '💻',
    description: 'Bureau mobile. Grand plan de travail, éclairage cocooning, ventilation, panneau solaire.',
    defaultVanId: 'mercedes-sprinter-l3h2',
    objects: [
      { productId: 'ikea-norberg', position: [1500, 500, 700], rotation: [0, 0, 0], layerId: 'bureau' },
      { productId: 'ikea-terje', position: [1500, 0, 300], rotation: [0, 0, 0], layerId: 'bureau' },
      { productId: 'ikea-kallax-4x1', position: [800, 0, -700], rotation: [0, 0, 0], layerId: 'rangement' },
      { productId: 'ikea-malfors-140', position: [3000, 400, 0], rotation: [0, Math.PI / 2, 0], layerId: 'couchage' },
      { productId: 'ikea-raskog', position: [500, 0, 500], rotation: [0, 0, 0], layerId: 'cuisine' },
      { productId: 'ikea-ledberg', position: [1500, 1800, 700], rotation: [0, 0, 0], layerId: 'eclairage' },
      { productId: 'elec-batt-lifepo4-200', position: [300, 0, -600], rotation: [0, 0, 0], layerId: 'electrique' },
      { productId: 'elec-solar-200w', position: [1500, 1900, 0], rotation: [0, 0, 0], layerId: 'electrique' },
      { productId: 'elec-maxxair', position: [2000, 1900, 0], rotation: [0, 0, 0], layerId: 'electrique' }
    ],
    estimatedBudget: 2350,
    estimatedWeight: 175,
    tags: ['télétravail', 'bureau', 'confort']
  },
  {
    id: 'bivouac-minimaliste',
    name: 'Bivouac Minimaliste',
    icon: '⛺',
    description: 'Le strict essentiel pour bivouaquer. Banquette-lit, kitchenette portable, autonomie basique.',
    defaultVanId: 'vw-t3-westfalia',
    objects: [
      { productId: 'ikea-malfors-140', position: [1500, 300, 0], rotation: [0, Math.PI / 2, 0], layerId: 'couchage' },
      { productId: 'dcth-mh100-rechaud', position: [400, 500, 500], rotation: [0, 0, 0], layerId: 'cuisine' },
      { productId: 'dcth-mh500-popote', position: [400, 500, 300], rotation: [0, 0, 0], layerId: 'cuisine' },
      { productId: 'dcth-glaciere-25', position: [400, 0, -500], rotation: [0, 0, 0], layerId: 'cuisine' },
      { productId: 'dcth-jerrican-10', position: [400, 0, -700], rotation: [0, 0, 0], layerId: 'eau' },
      { productId: 'dcth-bl900', position: [1000, 1100, 0], rotation: [0, 0, 0], layerId: 'eclairage' }
    ],
    estimatedBudget: 620,
    estimatedWeight: 42,
    tags: ['minimaliste', 'bivouac', 'léger']
  }
]
