// Catalogue produits VanPlanner 3D — sélection van-life IKEA / Décathlon / Van Specialist / Électrique
// Dimensions et prix issus des données publiques constructeurs, arrondis.

export interface Product {
  id: string
  source: 'ikea' | 'decathlon' | 'van' | 'electrical'
  reference: string
  name: string
  category: string
  subcategory: string
  dimensions: { length: number; width: number; height: number } // mm
  weight: number // grammes
  price: number // EUR
  color: string
  colorName: string
  material: string[]
  tags: string[]
  vanRating: 1 | 2 | 3 | 4 | 5
  notes?: string
}

export const catalog: Product[] = [
  // === IKEA — Rangements ===
  { id: 'ikea-kallax-2x2', source: 'ikea', reference: '203.795.29', name: 'KALLAX 2×2', category: 'Rangement', subcategory: 'Étagère cube', dimensions: { length: 770, width: 390, height: 770 }, weight: 22000, price: 59.99, color: '#f7fafc', colorName: 'Blanc', material: ['Aggloméré', 'Papier'], tags: ['modulaire', 'van-friendly'], vanRating: 4 },
  { id: 'ikea-kallax-4x1', source: 'ikea', reference: '702.758.87', name: 'KALLAX 4×1', category: 'Rangement', subcategory: 'Étagère colonne', dimensions: { length: 420, width: 390, height: 1470 }, weight: 24000, price: 54.99, color: '#f7fafc', colorName: 'Blanc', material: ['Aggloméré'], tags: ['vertical', 'colonne'], vanRating: 5 },
  { id: 'ikea-eket', source: 'ikea', reference: '803.339.55', name: 'EKET Cube', category: 'Rangement', subcategory: 'Cube compact', dimensions: { length: 350, width: 350, height: 350 }, weight: 5500, price: 20.00, color: '#e2e8f0', colorName: 'Blanc', material: ['Aggloméré'], tags: ['compact', 'modulaire'], vanRating: 5 },
  { id: 'ikea-ivar', source: 'ikea', reference: '898.406.20', name: 'IVAR Module', category: 'Rangement', subcategory: 'Étagère bois', dimensions: { length: 890, width: 500, height: 1790 }, weight: 26000, price: 89.00, color: '#d69e2e', colorName: 'Pin brut', material: ['Pin massif'], tags: ['bois', 'modulaire'], vanRating: 3 },
  { id: 'ikea-samla-11', source: 'ikea', reference: '301.029.72', name: 'SAMLA 11L', category: 'Rangement', subcategory: 'Boîte transparente', dimensions: { length: 390, width: 280, height: 140 }, weight: 620, price: 3.99, color: '#e2e8f0', colorName: 'Transparent', material: ['Plastique PP'], tags: ['empilable', 'étanche'], vanRating: 5 },
  { id: 'ikea-samla-45', source: 'ikea', reference: '901.029.71', name: 'SAMLA 45L', category: 'Rangement', subcategory: 'Boîte transparente', dimensions: { length: 570, width: 390, height: 280 }, weight: 1800, price: 7.99, color: '#e2e8f0', colorName: 'Transparent', material: ['Plastique PP'], tags: ['empilable', 'grand volume'], vanRating: 5 },
  { id: 'ikea-skadis', source: 'ikea', reference: '803.216.15', name: 'SKÅDIS 56×56', category: 'Rangement', subcategory: 'Panneau perforé', dimensions: { length: 560, width: 15, height: 560 }, weight: 3200, price: 15.00, color: '#f7fafc', colorName: 'Blanc', material: ['MDF'], tags: ['mural', 'organisation'], vanRating: 4 },

  // === IKEA — Cuisine ===
  { id: 'ikea-sunnersta', source: 'ikea', reference: '191.925.06', name: 'SUNNERSTA Mini-cuisine', category: 'Cuisine', subcategory: 'Mini-cuisine complète', dimensions: { length: 1120, width: 560, height: 1390 }, weight: 60000, price: 199.00, color: '#f7fafc', colorName: 'Blanc', material: ['Acier', 'Aggloméré'], tags: ['évier', 'complet', 'van-parfait'], vanRating: 5, notes: 'La mini-cuisine idéale van' },
  { id: 'ikea-raskog', source: 'ikea', reference: '301.523.13', name: 'RÅSKOG Desserte', category: 'Cuisine', subcategory: 'Desserte roulante', dimensions: { length: 350, width: 450, height: 780 }, weight: 8500, price: 49.99, color: '#38a169', colorName: 'Vert', material: ['Acier'], tags: ['roulettes', 'icône van-life'], vanRating: 5 },
  { id: 'ikea-ronnskar', source: 'ikea', reference: '502.121.90', name: 'RÖNNSKÄR Desserte', category: 'Cuisine', subcategory: 'Desserte inox', dimensions: { length: 370, width: 370, height: 780 }, weight: 6500, price: 39.99, color: '#a0aec0', colorName: 'Inox', material: ['Acier inoxydable'], tags: ['inox', 'compact'], vanRating: 4 },

  // === IKEA — Couchage ===
  { id: 'ikea-malfors-90', source: 'ikea', reference: '203.727.99', name: 'MALFORS Matelas 90×200', category: 'Couchage', subcategory: 'Matelas mousse', dimensions: { length: 2000, width: 900, height: 180 }, weight: 12000, price: 129.00, color: '#ffffff', colorName: 'Blanc', material: ['Mousse polyuréthane'], tags: ['couchage', 'ferme'], vanRating: 4 },
  { id: 'ikea-malfors-140', source: 'ikea', reference: '803.727.98', name: 'MALFORS Matelas 140×200', category: 'Couchage', subcategory: 'Matelas mousse', dimensions: { length: 2000, width: 1400, height: 180 }, weight: 18000, price: 199.00, color: '#ffffff', colorName: 'Blanc', material: ['Mousse polyuréthane'], tags: ['couchage', '2 places'], vanRating: 5 },

  // === IKEA — Textile ===
  { id: 'ikea-marjun', source: 'ikea', reference: '203.086.14', name: 'MARJUN Rideau occultant', category: 'Textile', subcategory: 'Rideau occultant', dimensions: { length: 1450, width: 20, height: 2500 }, weight: 2400, price: 39.99, color: '#2d3748', colorName: 'Gris foncé', material: ['Polyester'], tags: ['occultant', 'nuit'], vanRating: 5 },

  // === IKEA — Éclairage ===
  { id: 'ikea-ledberg', source: 'ikea', reference: '303.649.06', name: 'LEDBERG Ruban LED', category: 'Éclairage', subcategory: 'Ruban LED', dimensions: { length: 1500, width: 15, height: 15 }, weight: 200, price: 12.99, color: '#f7fafc', colorName: 'Blanc chaud', material: ['LED', 'Plastique'], tags: ['LED', '12V compatible'], vanRating: 5 },
  { id: 'ikea-lampan', source: 'ikea', reference: '200.469.88', name: 'LAMPAN Lampe chevet', category: 'Éclairage', subcategory: 'Lampe chevet', dimensions: { length: 190, width: 190, height: 290 }, weight: 900, price: 12.99, color: '#f7fafc', colorName: 'Blanc', material: ['Plastique'], tags: ['ambiance'], vanRating: 3 },

  // === IKEA — Sièges & Tables ===
  { id: 'ikea-norberg', source: 'ikea', reference: '903.798.51', name: 'NORBERG Table murale', category: 'Table', subcategory: 'Table rabattable', dimensions: { length: 740, width: 600, height: 750 }, weight: 9000, price: 34.99, color: '#f7fafc', colorName: 'Blanc', material: ['Aggloméré'], tags: ['rabattable', 'gain place'], vanRating: 5 },
  { id: 'ikea-terje', source: 'ikea', reference: '702.020.10', name: 'TERJE Chaise pliante', category: 'Siège', subcategory: 'Chaise pliante', dimensions: { length: 440, width: 510, height: 770 }, weight: 4200, price: 24.99, color: '#d69e2e', colorName: 'Bouleau', material: ['Bouleau massif'], tags: ['pliable', 'bois'], vanRating: 5 },
  { id: 'ikea-frosta', source: 'ikea', reference: '901.436.34', name: 'FROSTA Tabouret', category: 'Siège', subcategory: 'Tabouret bois', dimensions: { length: 355, width: 355, height: 450 }, weight: 3400, price: 14.99, color: '#d69e2e', colorName: 'Bouleau', material: ['Bouleau'], tags: ['empilable'], vanRating: 4 },

  // === Décathlon — Couchage ===
  { id: 'dcth-air-comfort-2p', source: 'decathlon', reference: '8583720', name: 'Quechua Air Comfort 140', category: 'Couchage', subcategory: 'Matelas gonflable', dimensions: { length: 2000, width: 1400, height: 200 }, weight: 5500, price: 79.99, color: '#2b6cb0', colorName: 'Bleu', material: ['PVC'], tags: ['gonflable', '2 places'], vanRating: 4 },
  { id: 'dcth-arpenaz-10', source: 'decathlon', reference: '8394215', name: 'Quechua Arpenaz 10°', category: 'Couchage', subcategory: 'Sac de couchage', dimensions: { length: 2200, width: 800, height: 80 }, weight: 1500, price: 24.99, color: '#2c5282', colorName: 'Bleu', material: ['Polyester', 'Ouate'], tags: ['sac', 'compact'], vanRating: 5 },

  // === Décathlon — Cuisine ===
  { id: 'dcth-mh100-rechaud', source: 'decathlon', reference: '8583721', name: 'Quechua MH100 Réchaud gaz', category: 'Cuisine', subcategory: 'Réchaud portable', dimensions: { length: 340, width: 270, height: 90 }, weight: 1200, price: 19.99, color: '#e53e3e', colorName: 'Rouge', material: ['Acier'], tags: ['gaz', 'portable'], vanRating: 5 },
  { id: 'dcth-mh500-popote', source: 'decathlon', reference: '8583722', name: 'Quechua MH500 Popote 4P', category: 'Cuisine', subcategory: 'Popote', dimensions: { length: 220, width: 220, height: 150 }, weight: 950, price: 34.99, color: '#a0aec0', colorName: 'Inox', material: ['Inox'], tags: ['4 personnes', 'empilable'], vanRating: 5 },

  // === Décathlon — Glacières ===
  { id: 'dcth-glaciere-25', source: 'decathlon', reference: '8583723', name: 'Quechua Glacière 25L', category: 'Cuisine', subcategory: 'Glacière passive', dimensions: { length: 420, width: 300, height: 350 }, weight: 3800, price: 39.99, color: '#3182ce', colorName: 'Bleu', material: ['Plastique', 'Mousse'], tags: ['isotherme', '25L'], vanRating: 5 },
  { id: 'dcth-glaciere-compressor-35', source: 'decathlon', reference: '8583724', name: 'Glacière compressor 35L 12V', category: 'Cuisine', subcategory: 'Glacière électrique', dimensions: { length: 620, width: 380, height: 400 }, weight: 15500, price: 399.00, color: '#1a202c', colorName: 'Noir', material: ['Plastique', 'Acier'], tags: ['12V', 'compressor', 'frigo'], vanRating: 5 },

  // === Décathlon — Eau ===
  { id: 'dcth-jerrican-10', source: 'decathlon', reference: '8583725', name: 'Jerrican 10L', category: 'Eau', subcategory: 'Jerrican rigide', dimensions: { length: 300, width: 180, height: 350 }, weight: 700, price: 9.99, color: '#f7fafc', colorName: 'Translucide', material: ['Plastique alimentaire'], tags: ['10L', 'robinet'], vanRating: 5 },
  { id: 'dcth-douche-solaire', source: 'decathlon', reference: '8583726', name: 'Douche solaire 10L', category: 'Sanitaire', subcategory: 'Douche portable', dimensions: { length: 300, width: 50, height: 500 }, weight: 400, price: 14.99, color: '#1a202c', colorName: 'Noir', material: ['PVC'], tags: ['solaire', 'nomade'], vanRating: 4 },

  // === Décathlon — Éclairage ===
  { id: 'dcth-bl500', source: 'decathlon', reference: '8583727', name: 'Quechua BL500 Lampe', category: 'Éclairage', subcategory: 'Lampe camping USB', dimensions: { length: 95, width: 95, height: 175 }, weight: 350, price: 24.99, color: '#f97316', colorName: 'Orange', material: ['Plastique'], tags: ['USB rechargeable', '500 lumens'], vanRating: 5 },
  { id: 'dcth-bl900', source: 'decathlon', reference: '8583728', name: 'Quechua BL900 Lampe', category: 'Éclairage', subcategory: 'Lampe camping USB', dimensions: { length: 130, width: 130, height: 130 }, weight: 550, price: 39.99, color: '#f97316', colorName: 'Orange', material: ['Plastique'], tags: ['USB', '900 lumens'], vanRating: 5 },

  // === Décathlon — Solaire ===
  { id: 'dcth-solaire-20w', source: 'decathlon', reference: '8583729', name: 'Panneau solaire pliable 20W', category: 'Électricité', subcategory: 'Panneau solaire', dimensions: { length: 400, width: 300, height: 25 }, weight: 1200, price: 79.99, color: '#1a202c', colorName: 'Noir', material: ['Silicium mono'], tags: ['pliable', '20W', 'USB'], vanRating: 5 },

  // === Décathlon — Sièges & tables ===
  { id: 'dcth-chaise-comfort', source: 'decathlon', reference: '8583730', name: 'Quechua Comfort chaise', category: 'Siège', subcategory: 'Chaise pliante', dimensions: { length: 550, width: 550, height: 900 }, weight: 3200, price: 34.99, color: '#2c5282', colorName: 'Bleu', material: ['Aluminium', 'Polyester'], tags: ['pliable', 'confort'], vanRating: 5 },
  { id: 'dcth-table-mh500', source: 'decathlon', reference: '8583731', name: 'Quechua MH500 Table 4P', category: 'Table', subcategory: 'Table pliante', dimensions: { length: 1100, width: 700, height: 700 }, weight: 5500, price: 49.99, color: '#a0aec0', colorName: 'Gris', material: ['Aluminium'], tags: ['pliable', '4 personnes'], vanRating: 5 },

  // === Van Specialist ===
  { id: 'van-baie-reimo-700', source: 'van', reference: 'REIMO-700', name: 'Baie coulissante Reimo 700×450', category: 'Ouvrant', subcategory: 'Baie latérale', dimensions: { length: 700, width: 60, height: 450 }, weight: 5500, price: 289.00, color: '#4a5568', colorName: 'Gris', material: ['Alu', 'Verre'], tags: ['coulissant', 'occultant'], vanRating: 5 },
  { id: 'van-heki-700', source: 'van', reference: 'HEKI-700', name: 'Lanterneau Heki 2 700×500', category: 'Ouvrant', subcategory: 'Lanterneau toit', dimensions: { length: 700, width: 500, height: 150 }, weight: 6800, price: 449.00, color: '#e2e8f0', colorName: 'Translucide', material: ['Plexi', 'Alu'], tags: ['toit', 'ventilation'], vanRating: 5 },
  { id: 'van-thetford-c223', source: 'van', reference: 'THETFORD-C223', name: 'Thetford C223 WC chimique', category: 'Sanitaire', subcategory: 'WC portable', dimensions: { length: 388, width: 458, height: 380 }, weight: 12500, price: 449.00, color: '#a0aec0', colorName: 'Gris', material: ['Plastique'], tags: ['WC', 'chimique'], vanRating: 5 },
  { id: 'van-truma-combi-4e', source: 'van', reference: 'TRUMA-4E', name: 'Truma Combi 4E chauffage', category: 'Chauffage', subcategory: 'Chauffage gaz/élec', dimensions: { length: 510, width: 450, height: 300 }, weight: 15200, price: 1890.00, color: '#f7fafc', colorName: 'Blanc', material: ['Acier'], tags: ['chauffage', 'eau chaude', '4kW'], vanRating: 5 },

  // === Électrique ===
  { id: 'elec-batt-lifepo4-100', source: 'electrical', reference: 'VICTRON-LFP-100', name: 'Batterie LiFePO4 100Ah Victron', category: 'Électricité', subcategory: 'Batterie', dimensions: { length: 322, width: 176, height: 220 }, weight: 13000, price: 1099.00, color: '#1a202c', colorName: 'Noir', material: ['Lithium', 'Acier'], tags: ['LiFePO4', '100Ah', '12V'], vanRating: 5 },
  { id: 'elec-batt-lifepo4-200', source: 'electrical', reference: 'VICTRON-LFP-200', name: 'Batterie LiFePO4 200Ah Victron', category: 'Électricité', subcategory: 'Batterie', dimensions: { length: 522, width: 220, height: 220 }, weight: 26000, price: 1899.00, color: '#1a202c', colorName: 'Noir', material: ['Lithium', 'Acier'], tags: ['LiFePO4', '200Ah'], vanRating: 5 },
  { id: 'elec-solar-100w', source: 'electrical', reference: 'SOLAR-100', name: 'Panneau solaire rigide 100W', category: 'Électricité', subcategory: 'Panneau solaire', dimensions: { length: 1000, width: 670, height: 35 }, weight: 6500, price: 129.00, color: '#1a202c', colorName: 'Noir', material: ['Silicium mono', 'Alu'], tags: ['toit', '100W'], vanRating: 5 },
  { id: 'elec-solar-200w', source: 'electrical', reference: 'SOLAR-200', name: 'Panneau solaire rigide 200W', category: 'Électricité', subcategory: 'Panneau solaire', dimensions: { length: 1580, width: 810, height: 35 }, weight: 12500, price: 249.00, color: '#1a202c', colorName: 'Noir', material: ['Silicium mono', 'Alu'], tags: ['toit', '200W'], vanRating: 5 },
  { id: 'elec-mppt-victron-100-20', source: 'electrical', reference: 'VICTRON-100/20', name: 'MPPT Victron 100/20', category: 'Électricité', subcategory: 'Régulateur', dimensions: { length: 130, width: 100, height: 40 }, weight: 500, price: 149.00, color: '#2c5282', colorName: 'Bleu', material: ['Plastique'], tags: ['MPPT', '20A', 'Bluetooth'], vanRating: 5 },
  { id: 'elec-onduleur-1000', source: 'electrical', reference: 'VICTRON-INV-1000', name: 'Onduleur pur sinus 1000W', category: 'Électricité', subcategory: 'Onduleur', dimensions: { length: 260, width: 180, height: 90 }, weight: 4200, price: 349.00, color: '#2c5282', colorName: 'Bleu', material: ['Métal'], tags: ['1000W', 'pur sinus'], vanRating: 5 },
  { id: 'elec-frigo-crx65', source: 'electrical', reference: 'DOMETIC-CRX65', name: 'Frigo Dometic CRX 65', category: 'Électricité', subcategory: 'Frigo compressor', dimensions: { length: 525, width: 486, height: 550 }, weight: 18500, price: 899.00, color: '#f7fafc', colorName: 'Blanc', material: ['Acier'], tags: ['12V', '65L', 'compressor'], vanRating: 5 },
  { id: 'elec-maxxair', source: 'electrical', reference: 'MAXXAIR-7500K', name: 'Ventilateur toit Maxxair 7500K', category: 'Électricité', subcategory: 'Ventilation', dimensions: { length: 400, width: 400, height: 130 }, weight: 3800, price: 449.00, color: '#f7fafc', colorName: 'Blanc', material: ['Plastique'], tags: ['12V', 'ventilation', 'toit'], vanRating: 5 }
]

export const categoryColors: Record<string, string> = {
  'Rangement': '#f97316',
  'Cuisine': '#e53e3e',
  'Couchage': '#805ad5',
  'Textile': '#d53f8c',
  'Éclairage': '#ecc94b',
  'Table': '#38a169',
  'Siège': '#48bb78',
  'Eau': '#3182ce',
  'Sanitaire': '#0987a0',
  'Ouvrant': '#a0aec0',
  'Chauffage': '#c53030',
  'Électricité': '#4299e1'
}

export const sources = {
  ikea: { name: 'IKEA', color: '#0058a3' },
  decathlon: { name: 'Décathlon', color: '#0082c3' },
  van: { name: 'Van Specialist', color: '#f97316' },
  electrical: { name: 'Électrique', color: '#eab308' }
}
