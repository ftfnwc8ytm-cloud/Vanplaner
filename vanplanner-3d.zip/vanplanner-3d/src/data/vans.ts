// Bibliothèque de vans — dimensions issues des fiches constructeur publiques (arrondies).
// À vérifier avant fabrication réelle.

export interface Van {
  id: string
  brand: string
  model: string
  variant: string
  years: string
  category: 'heritage' | 'compact' | 'medium' | 'large' | 'premium'
  interior: { length: number; width: number; height: number } // mm
  wheelWells: Array<{ x: number; y: number; width: number; depth: number; height: number }>
  payload: number // kg
  gvw: number // kg
  color: string
  popTop?: { raisedHeight: number; lengthCovered: number; xStart: number }
}

export const vans: Van[] = [
  // === VW Transporter T1 → T5 ===
  {
    id: 'vw-t1', brand: 'Volkswagen', model: 'Transporter T1', variant: 'Combi Split',
    years: '1950-1967', category: 'heritage',
    interior: { length: 2600, width: 1500, height: 1350 },
    wheelWells: [{ x: 800, y: 600, width: 500, depth: 350, height: 400 }, { x: 800, y: -600, width: 500, depth: 350, height: 400 }],
    payload: 750, gvw: 2100, color: '#c53030'
  },
  {
    id: 'vw-t2', brand: 'Volkswagen', model: 'Transporter T2', variant: 'Bay Window',
    years: '1967-1979', category: 'heritage',
    interior: { length: 2800, width: 1550, height: 1400 },
    wheelWells: [{ x: 850, y: 620, width: 500, depth: 350, height: 400 }, { x: 850, y: -620, width: 500, depth: 350, height: 400 }],
    payload: 900, gvw: 2300, color: '#dd6b20'
  },
  {
    id: 'vw-t3', brand: 'Volkswagen', model: 'Transporter T3', variant: 'Vanagon',
    years: '1979-1992', category: 'heritage',
    interior: { length: 2950, width: 1600, height: 1400 },
    wheelWells: [{ x: 900, y: 640, width: 500, depth: 350, height: 400 }, { x: 900, y: -640, width: 500, depth: 350, height: 400 }],
    payload: 950, gvw: 2500, color: '#d69e2e'
  },
  {
    id: 'vw-t3-westfalia', brand: 'Volkswagen', model: 'Transporter T3', variant: 'Westfalia Joker',
    years: '1979-1992', category: 'heritage',
    interior: { length: 2950, width: 1600, height: 1400 },
    wheelWells: [{ x: 900, y: 640, width: 500, depth: 350, height: 400 }, { x: 900, y: -640, width: 500, depth: 350, height: 400 }],
    payload: 900, gvw: 2500, color: '#38a169',
    popTop: { raisedHeight: 2100, lengthCovered: 1800, xStart: 400 }
  },
  {
    id: 'vw-t4-l1', brand: 'Volkswagen', model: 'Transporter T4', variant: 'L1H1',
    years: '1990-2003', category: 'medium',
    interior: { length: 2650, width: 1650, height: 1350 },
    wheelWells: [{ x: 850, y: 660, width: 450, depth: 300, height: 350 }, { x: 850, y: -660, width: 450, depth: 300, height: 350 }],
    payload: 900, gvw: 2600, color: '#3182ce'
  },
  {
    id: 'vw-t4-l2', brand: 'Volkswagen', model: 'Transporter T4', variant: 'L2H1',
    years: '1990-2003', category: 'medium',
    interior: { length: 3050, width: 1650, height: 1350 },
    wheelWells: [{ x: 950, y: 660, width: 450, depth: 300, height: 350 }, { x: 950, y: -660, width: 450, depth: 300, height: 350 }],
    payload: 1000, gvw: 2800, color: '#2b6cb0'
  },
  {
    id: 'vw-t5-l1', brand: 'Volkswagen', model: 'Transporter T5', variant: 'L1H1',
    years: '2003-2015', category: 'medium',
    interior: { length: 2570, width: 1700, height: 1410 },
    wheelWells: [{ x: 850, y: 680, width: 450, depth: 300, height: 350 }, { x: 850, y: -680, width: 450, depth: 300, height: 350 }],
    payload: 1000, gvw: 2800, color: '#2c5282'
  },
  {
    id: 'vw-t5-california', brand: 'Volkswagen', model: 'Transporter T5', variant: 'California SE',
    years: '2003-2015', category: 'medium',
    interior: { length: 2570, width: 1700, height: 1410 },
    wheelWells: [{ x: 850, y: 680, width: 450, depth: 300, height: 350 }, { x: 850, y: -680, width: 450, depth: 300, height: 350 }],
    payload: 950, gvw: 2800, color: '#4299e1',
    popTop: { raisedHeight: 2000, lengthCovered: 1600, xStart: 350 }
  },

  // === Vans moyens populaires ===
  {
    id: 'renault-trafic-l1', brand: 'Renault', model: 'Trafic', variant: 'L1H1',
    years: '2014-', category: 'medium',
    interior: { length: 2537, width: 1662, height: 1387 },
    wheelWells: [{ x: 850, y: 665, width: 450, depth: 300, height: 350 }, { x: 850, y: -665, width: 450, depth: 300, height: 350 }],
    payload: 1200, gvw: 2900, color: '#718096'
  },
  {
    id: 'mercedes-vito-l2', brand: 'Mercedes', model: 'Vito', variant: 'L2',
    years: '2014-', category: 'medium',
    interior: { length: 2830, width: 1690, height: 1390 },
    wheelWells: [{ x: 900, y: 680, width: 450, depth: 300, height: 350 }, { x: 900, y: -680, width: 450, depth: 300, height: 350 }],
    payload: 1100, gvw: 3050, color: '#a0aec0'
  },
  {
    id: 'ford-custom-l2', brand: 'Ford', model: 'Transit Custom', variant: 'L2H1 Nugget',
    years: '2018-', category: 'medium',
    interior: { length: 2955, width: 1775, height: 1406 },
    wheelWells: [{ x: 950, y: 700, width: 450, depth: 300, height: 350 }, { x: 950, y: -700, width: 450, depth: 300, height: 350 }],
    payload: 1150, gvw: 3100, color: '#4a5568'
  },
  {
    id: 'vw-t6-california', brand: 'Volkswagen', model: 'Transporter T6.1', variant: 'California Ocean',
    years: '2019-', category: 'medium',
    interior: { length: 2970, width: 1700, height: 1410 },
    wheelWells: [{ x: 950, y: 680, width: 450, depth: 300, height: 350 }, { x: 950, y: -680, width: 450, depth: 300, height: 350 }],
    payload: 950, gvw: 3080, color: '#5a67d8',
    popTop: { raisedHeight: 2050, lengthCovered: 1700, xStart: 400 }
  },

  // === Grands fourgons ===
  {
    id: 'fiat-ducato-l2h2', brand: 'Fiat', model: 'Ducato', variant: 'L2H2',
    years: '2014-', category: 'large',
    interior: { length: 3120, width: 1870, height: 1932 },
    wheelWells: [{ x: 1000, y: 750, width: 500, depth: 300, height: 350 }, { x: 1000, y: -750, width: 500, depth: 300, height: 350 }],
    payload: 1600, gvw: 3500, color: '#e53e3e'
  },
  {
    id: 'fiat-ducato-l3h2', brand: 'Fiat', model: 'Ducato', variant: 'L3H2',
    years: '2014-', category: 'large',
    interior: { length: 3705, width: 1870, height: 1932 },
    wheelWells: [{ x: 1200, y: 750, width: 500, depth: 300, height: 350 }, { x: 1200, y: -750, width: 500, depth: 300, height: 350 }],
    payload: 1550, gvw: 3500, color: '#c53030'
  },
  {
    id: 'fiat-ducato-l4h3', brand: 'Fiat', model: 'Ducato', variant: 'L4H3 Maxi',
    years: '2014-', category: 'large',
    interior: { length: 4070, width: 1870, height: 2172 },
    wheelWells: [{ x: 1300, y: 750, width: 500, depth: 300, height: 350 }, { x: 1300, y: -750, width: 500, depth: 300, height: 350 }],
    payload: 1900, gvw: 4250, color: '#9b2c2c'
  },
  {
    id: 'peugeot-boxer-l3h2', brand: 'Peugeot', model: 'Boxer', variant: 'L3H2',
    years: '2014-', category: 'large',
    interior: { length: 3705, width: 1870, height: 1932 },
    wheelWells: [{ x: 1200, y: 750, width: 500, depth: 300, height: 350 }, { x: 1200, y: -750, width: 500, depth: 300, height: 350 }],
    payload: 1550, gvw: 3500, color: '#2b6cb0'
  },
  {
    id: 'mercedes-sprinter-l3h2', brand: 'Mercedes', model: 'Sprinter', variant: 'L3H2 (VS30)',
    years: '2018-', category: 'large',
    interior: { length: 3733, width: 1787, height: 1968 },
    wheelWells: [{ x: 1200, y: 720, width: 500, depth: 300, height: 350 }, { x: 1200, y: -720, width: 500, depth: 300, height: 350 }],
    payload: 1400, gvw: 3500, color: '#4a5568'
  },
  {
    id: 'vw-crafter-l3h3', brand: 'Volkswagen', model: 'Crafter', variant: 'L3H3',
    years: '2017-', category: 'large',
    interior: { length: 3733, width: 1832, height: 2189 },
    wheelWells: [{ x: 1200, y: 730, width: 500, depth: 300, height: 350 }, { x: 1200, y: -730, width: 500, depth: 300, height: 350 }],
    payload: 1450, gvw: 3500, color: '#38a169'
  },
  {
    id: 'ford-transit-l3h2', brand: 'Ford', model: 'Transit', variant: 'L3H2 Trend',
    years: '2019-', category: 'large',
    interior: { length: 3750, width: 1784, height: 1886 },
    wheelWells: [{ x: 1200, y: 715, width: 500, depth: 300, height: 350 }, { x: 1200, y: -715, width: 500, depth: 300, height: 350 }],
    payload: 1500, gvw: 3500, color: '#2c5282'
  },
  {
    id: 'renault-master-l3h2', brand: 'Renault', model: 'Master', variant: 'L3H2',
    years: '2019-', category: 'large',
    interior: { length: 3733, width: 1765, height: 1894 },
    wheelWells: [{ x: 1200, y: 710, width: 500, depth: 300, height: 350 }, { x: 1200, y: -710, width: 500, depth: 300, height: 350 }],
    payload: 1500, gvw: 3500, color: '#d69e2e'
  },
  {
    id: 'iveco-daily-35s', brand: 'Iveco', model: 'Daily', variant: '35S L3H2',
    years: '2019-', category: 'large',
    interior: { length: 3540, width: 1800, height: 1900 },
    wheelWells: [{ x: 1150, y: 720, width: 500, depth: 300, height: 350 }, { x: 1150, y: -720, width: 500, depth: 300, height: 350 }],
    payload: 1600, gvw: 3500, color: '#805ad5'
  },

  // === Premium ===
  {
    id: 'mercedes-sprinter-4x4', brand: 'Mercedes', model: 'Sprinter', variant: '4×4 L3H2',
    years: '2018-', category: 'premium',
    interior: { length: 3733, width: 1787, height: 1968 },
    wheelWells: [{ x: 1200, y: 720, width: 550, depth: 350, height: 400 }, { x: 1200, y: -720, width: 550, depth: 350, height: 400 }],
    payload: 1200, gvw: 3500, color: '#1a202c'
  },
  {
    id: 'ram-promaster-159', brand: 'RAM', model: 'ProMaster', variant: '159"',
    years: '2014-', category: 'premium',
    interior: { length: 3630, width: 1870, height: 1930 },
    wheelWells: [{ x: 1180, y: 750, width: 500, depth: 300, height: 350 }, { x: 1180, y: -750, width: 500, depth: 300, height: 350 }],
    payload: 1900, gvw: 4085, color: '#e53e3e'
  }
]

export const vanCategories: Record<Van['category'], string> = {
  heritage: 'Historique',
  compact: 'Compact',
  medium: 'Moyen',
  large: 'Grand fourgon',
  premium: 'Premium'
}
