import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { vans, Van } from '../data/vans'
import { presets } from '../data/presets'

export interface SceneObject {
  id: string
  productId: string
  position: [number, number, number] // mm dans le repère van
  rotation: [number, number, number]
  layerId: string
  locked?: boolean
}

export interface Layer {
  id: string
  name: string
  visible: boolean
  locked: boolean
  color: string
}

interface SceneState {
  vanId: string
  popTopRaised: boolean
  objects: SceneObject[]
  layers: Layer[]
  selectedIds: string[]
  renderMode: 'wireframe' | 'solid' | 'shaded' | 'sketchup'
  showGrid: boolean
  multiView: boolean

  setVan: (id: string) => void
  setPopTop: (raised: boolean) => void
  addObject: (o: Omit<SceneObject, 'id'>) => string
  updateObject: (id: string, patch: Partial<SceneObject>) => void
  removeObject: (id: string) => void
  selectObject: (id: string | null, additive?: boolean) => void
  clearScene: () => void
  loadPreset: (presetId: string) => void
  toggleLayer: (id: string) => void
  setRenderMode: (m: SceneState['renderMode']) => void
  toggleMultiView: () => void
  toggleGrid: () => void
  currentVan: () => Van
}

const defaultLayers: Layer[] = [
  { id: 'structure', name: 'Structure', visible: true, locked: false, color: '#a0aec0' },
  { id: 'mobilier', name: 'Mobilier', visible: true, locked: false, color: '#d69e2e' },
  { id: 'cuisine', name: 'Cuisine', visible: true, locked: false, color: '#e53e3e' },
  { id: 'couchage', name: 'Couchage', visible: true, locked: false, color: '#805ad5' },
  { id: 'electrique', name: 'Électrique', visible: true, locked: false, color: '#4299e1' },
  { id: 'eau', name: 'Eau', visible: true, locked: false, color: '#3182ce' },
  { id: 'sanitaire', name: 'Sanitaire', visible: true, locked: false, color: '#0987a0' },
  { id: 'chauffage', name: 'Chauffage', visible: true, locked: false, color: '#c53030' },
  { id: 'eclairage', name: 'Éclairage', visible: true, locked: false, color: '#ecc94b' },
  { id: 'textile', name: 'Textile', visible: true, locked: false, color: '#d53f8c' },
  { id: 'rangement', name: 'Rangement', visible: true, locked: false, color: '#f97316' },
  { id: 'bureau', name: 'Bureau', visible: true, locked: false, color: '#38a169' }
]

export const useSceneStore = create<SceneState>()(
  persist(
    (set, get) => ({
      vanId: 'fiat-ducato-l3h2',
      popTopRaised: false,
      objects: [],
      layers: defaultLayers,
      selectedIds: [],
      renderMode: 'shaded',
      showGrid: true,
      multiView: false,

      setVan: (id) => set({ vanId: id, objects: [], selectedIds: [] }),
      setPopTop: (raised) => set({ popTopRaised: raised }),

      addObject: (o) => {
        const id = `obj-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`
        set((s) => ({ objects: [...s.objects, { ...o, id }], selectedIds: [id] }))
        return id
      },

      updateObject: (id, patch) =>
        set((s) => ({
          objects: s.objects.map((o) => (o.id === id ? { ...o, ...patch } : o))
        })),

      removeObject: (id) =>
        set((s) => ({
          objects: s.objects.filter((o) => o.id !== id),
          selectedIds: s.selectedIds.filter((sid) => sid !== id)
        })),

      selectObject: (id, additive = false) =>
        set((s) => {
          if (id === null) return { selectedIds: [] }
          if (additive) {
            return {
              selectedIds: s.selectedIds.includes(id)
                ? s.selectedIds.filter((sid) => sid !== id)
                : [...s.selectedIds, id]
            }
          }
          return { selectedIds: [id] }
        }),

      clearScene: () => set({ objects: [], selectedIds: [] }),

      loadPreset: (presetId) => {
        const p = presets.find((x) => x.id === presetId)
        if (!p) return
        const objects: SceneObject[] = p.objects.map((o, i) => ({
          id: `obj-${Date.now()}-${i}`,
          productId: o.productId,
          position: o.position,
          rotation: o.rotation,
          layerId: o.layerId
        }))
        set({ vanId: p.defaultVanId, objects, selectedIds: [] })
      },

      toggleLayer: (id) =>
        set((s) => ({
          layers: s.layers.map((l) => (l.id === id ? { ...l, visible: !l.visible } : l))
        })),

      setRenderMode: (m) => set({ renderMode: m }),
      toggleMultiView: () => set((s) => ({ multiView: !s.multiView })),
      toggleGrid: () => set((s) => ({ showGrid: !s.showGrid })),

      currentVan: () => vans.find((v) => v.id === get().vanId) || vans[0]
    }),
    { name: 'vanplanner-scene-v1' }
  )
)
