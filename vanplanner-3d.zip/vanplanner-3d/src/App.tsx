import { Toaster } from 'react-hot-toast'
import { Toolbar } from './components/Toolbar'
import { LeftPanel } from './components/LeftPanel'
import { RightPanel } from './components/RightPanel'
import { Viewport } from './components/Viewport'
import { useEffect } from 'react'
import { useSceneStore } from './stores/sceneStore'

export function App() {
  const objects = useSceneStore((s) => s.objects)
  const loadPreset = useSceneStore((s) => s.loadPreset)

  // Preset de démo au tout premier lancement (aucun objet en scène)
  useEffect(() => {
    if (objects.length === 0) {
      // Ne charge automatiquement qu'à la première visite (ni objets ni sauvegarde)
      const seen = localStorage.getItem('vanplanner-first-visit')
      if (!seen) {
        loadPreset('nomade-full-time')
        localStorage.setItem('vanplanner-first-visit', '1')
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <div className="w-screen h-screen flex flex-col bg-bg-900">
      <Toolbar />
      <div className="flex-1 flex overflow-hidden">
        <LeftPanel />
        <div className="flex-1 relative">
          <Viewport />
          <StatusBar />
        </div>
        <RightPanel />
      </div>
      <Toaster
        position="bottom-right"
        toastOptions={{
          style: { background: '#1f1f1f', color: '#fff', border: '1px solid #2a2a2a' }
        }}
      />
    </div>
  )
}

function StatusBar() {
  const van = useSceneStore((s) => s.currentVan())
  const count = useSceneStore((s) => s.objects.length)
  const isOnline = navigator.onLine

  return (
    <div className="absolute bottom-0 left-0 right-0 h-8 bg-bg-800 border-t border-bg-600 flex items-center px-3 text-xs text-gray-500 gap-4">
      <span>{van.brand} {van.model} {van.variant}</span>
      <span>{van.interior.length}×{van.interior.width}×{van.interior.height} mm</span>
      <span>{count} objet{count > 1 ? 's' : ''}</span>
      <div className="ml-auto flex items-center gap-3">
        <span className={isOnline ? 'text-green-500' : 'text-accent-orange'}>
          ● {isOnline ? 'En ligne' : 'Hors ligne (mode PWA)'}
        </span>
      </div>
    </div>
  )
}
