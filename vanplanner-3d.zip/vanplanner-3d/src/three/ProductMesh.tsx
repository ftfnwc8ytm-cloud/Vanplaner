import { useRef } from 'react'
import * as THREE from 'three'
import { catalog, categoryColors } from '../data/catalog'
import { useSceneStore, SceneObject } from '../stores/sceneStore'

interface Props {
  object: SceneObject
  selected: boolean
}

/**
 * Rendu 3D d'un produit du catalogue.
 * Utilise une BoxGeometry paramétrique colorée par catégorie (fallback simple).
 * Position/rotation en mm côté van → converties en mètres.
 */
export function ProductMesh({ object, selected }: Props) {
  const meshRef = useRef<THREE.Mesh>(null)
  const selectObject = useSceneStore((s) => s.selectObject)

  const product = catalog.find((p) => p.id === object.productId)
  if (!product) return null

  const L = product.dimensions.length / 1000
  const W = product.dimensions.width / 1000
  const H = product.dimensions.height / 1000
  const color = categoryColors[product.category] || product.color

  const px = object.position[0] / 1000
  const py = object.position[1] / 1000
  const pz = object.position[2] / 1000

  return (
    <group>
      <mesh
        ref={meshRef}
        position={[px + L / 2, py + H / 2, pz]}
        rotation={object.rotation as [number, number, number]}
        castShadow
        receiveShadow
        onClick={(e) => {
          e.stopPropagation()
          selectObject(object.id, e.shiftKey)
        }}
      >
        <boxGeometry args={[L, H, W]} />
        <meshStandardMaterial
          color={color}
          emissive={selected ? '#3b82f6' : '#000000'}
          emissiveIntensity={selected ? 0.35 : 0}
          roughness={0.7}
          metalness={0.1}
        />
      </mesh>
      {selected && (
        <mesh position={[px + L / 2, py + H / 2, pz]}>
          <boxGeometry args={[L + 0.02, H + 0.02, W + 0.02]} />
          <meshBasicMaterial color="#3b82f6" wireframe />
        </mesh>
      )}
    </group>
  )
}
