import { useMemo } from 'react'
import * as THREE from 'three'
import { Van } from '../data/vans'

interface Props {
  van: Van
  popTopRaised: boolean
  wireframe?: boolean
}

/**
 * Rendu 3D paramétrique du van (cellule intérieure + passages de roues + toit relevable)
 * Coordonnées en mètres. 1 mm = 0.001 unité Three.js.
 */
export function VanModel({ van, popTopRaised, wireframe }: Props) {
  const geometry = useMemo(() => {
    const L = van.interior.length / 1000
    const W = van.interior.width / 1000
    const H = (popTopRaised && van.popTop ? van.popTop.raisedHeight : van.interior.height) / 1000
    return { L, W, H }
  }, [van, popTopRaised])

  const wallMat = (
    <meshStandardMaterial
      color="#3a3a3a"
      side={THREE.DoubleSide}
      transparent
      opacity={0.15}
      wireframe={wireframe}
    />
  )

  return (
    <group>
      {/* Plancher */}
      <mesh position={[geometry.L / 2, 0, 0]} receiveShadow>
        <boxGeometry args={[geometry.L, 0.02, geometry.W]} />
        <meshStandardMaterial color="#2a2a2a" wireframe={wireframe} />
      </mesh>

      {/* Paroi gauche */}
      <mesh position={[geometry.L / 2, geometry.H / 2, -geometry.W / 2]}>
        <boxGeometry args={[geometry.L, geometry.H, 0.02]} />
        {wallMat}
      </mesh>

      {/* Paroi droite */}
      <mesh position={[geometry.L / 2, geometry.H / 2, geometry.W / 2]}>
        <boxGeometry args={[geometry.L, geometry.H, 0.02]} />
        {wallMat}
      </mesh>

      {/* Paroi arrière */}
      <mesh position={[geometry.L, geometry.H / 2, 0]}>
        <boxGeometry args={[0.02, geometry.H, geometry.W]} />
        {wallMat}
      </mesh>

      {/* Paroi avant (cabine) */}
      <mesh position={[0, geometry.H / 2, 0]}>
        <boxGeometry args={[0.02, geometry.H, geometry.W]} />
        {wallMat}
      </mesh>

      {/* Toit */}
      <mesh position={[geometry.L / 2, geometry.H, 0]}>
        <boxGeometry args={[geometry.L, 0.02, geometry.W]} />
        {wallMat}
      </mesh>

      {/* Passages de roues (zones interdites) */}
      {van.wheelWells.map((w, i) => (
        <mesh
          key={i}
          position={[w.x / 1000, w.height / 2000, w.y / 1000]}
          castShadow
        >
          <boxGeometry args={[w.width / 1000, w.height / 1000, w.depth / 1000]} />
          <meshStandardMaterial
            color="#c53030"
            transparent
            opacity={0.35}
            wireframe={wireframe}
          />
        </mesh>
      ))}

      {/* Toit relevable ouvert */}
      {popTopRaised && van.popTop && (
        <mesh
          position={[
            (van.popTop.xStart + van.popTop.lengthCovered / 2) / 1000,
            van.interior.height / 1000 + 0.1,
            0
          ]}
        >
          <boxGeometry
            args={[
              van.popTop.lengthCovered / 1000,
              0.02,
              geometry.W - 0.1
            ]}
          />
          <meshStandardMaterial color="#4a5568" transparent opacity={0.4} />
        </mesh>
      )}
    </group>
  )
}
